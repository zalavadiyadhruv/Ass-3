<?php

$server = "localhost";
$username = "root";
$password = "";
$database = "feedback";

$connection = mysqli_connect($server , $username , $password , $database);

if ($connection -> connect_error){
    die($connection -> connect_error);
}
else{
    echo "Connection Successful <br/> You Are now connected to Database: $database";
}

$name = $_REQUEST["name"];
$email = $_REQUEST["email"];
$subject = $_REQUEST["subject"];
$message = $_REQUEST["Message"]; 

$query = "INSERT INTO feedback VALUES ('$name','$email','$subject','$message' )"; 

if(mysqli_query($connection, $query)){  
    echo "Record inserted successfully";
}
else{  
   echo "Could not insert record: ". mysqli_error($connection);
}  
   
   mysqli_close($connection); 
?>